Result of Problem 1:

Sorted Employee List Based on Age 
[ Employee [name=Jhon, age=5]
,  Employee [name=Satish, age=10]
,  Employee [name=peter, age=20]
,  Employee [name=suhit, age=40]
,  Employee [name=Ankit, age=50]
,  Employee [name=Basheer, age=60]
]
Sorted Employee List Based on Age then By Name 
[ Employee [name=Ankit, age=50]
,  Employee [name=Basheer, age=60]
,  Employee [name=Jhon, age=5]
,  Employee [name=Satish, age=10]
,  Employee [name=peter, age=20]
,  Employee [name=suhit, age=40]
]
Sorted Employee List Based on Age then By Name and also age >10 
[ Employee [name=Ankit, age=50]
,  Employee [name=Basheer, age=60]
,  Employee [name=Satish, age=10]
,  Employee [name=peter, age=20]
,  Employee [name=suhit, age=40]
]


Result of Problem 2: